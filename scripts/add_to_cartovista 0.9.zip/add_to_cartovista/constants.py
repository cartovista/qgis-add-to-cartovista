OAUTH_CLIENT_ID = "3cba2e6269684a7f912e4cfac6a9811d"
#DEPLOYMENT_URL = "https://cloud.cartovista.com"
DEPLOYMENT_URL = "https://cloud-dev.cartovista.com"
#DEPLOYMENT_URL = "http://localhost:8000"