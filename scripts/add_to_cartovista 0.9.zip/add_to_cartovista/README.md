# Upload to CartoVista
This QGIS plugin lets you export layers and maps directly to the CartoVista platform. Styles and layer settings defined in QGIS are transimitted during export, so your data appears in CartoVista just the way you configured it.

Currently supported layer types: point, polygon, and polyline.
